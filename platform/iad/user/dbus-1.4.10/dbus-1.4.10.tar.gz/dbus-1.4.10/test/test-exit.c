/* This is a process that just exits with a failure code */
int
main (int argc, char **argv)
{

  return 1;
}
