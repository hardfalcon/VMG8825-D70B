#define VERSION		"2.4.5"
#define DATE		"6 September 2008"
