IIS and WinInet modules for gSOAP 

The modules are released under the gSOAP open source public license, see 
license.pdf in the gSOAP root dir of the package.

The IIS module enables integration of gSOAP in MS Window's internet information
server.
