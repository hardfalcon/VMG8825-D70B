/** file to include stdsoap2.cpp here, to get around directory location problems etc.
*/

/* You must set the include path in Visual Studio under tools|options|directories|include anway. 
   There also the file below can be found.
*/
#include "stdsoap2.cpp"
