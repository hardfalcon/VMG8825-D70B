h__hello(char*&);
